# Roadmap

- [x] Enable Lovable Cloud
- [x] Create `books` table with RLS + seed catalogue
- [x] Turn on email/password sign-in; add Google and Lovable sign-in
- [x] Design tokens: clean, modern, distinctive (src/styles.css)
- [x] Shared shell in `__root.tsx`: header, footer, toaster, auth listener, fonts
- [x] Catalogue home: search, category + availability filters, sort, grid
- [x] Add / edit book dialog with validation (trim, ISBN cleanup, year range)
- [x] Book detail page `/book/$id`
- [x] Sign-in / sign-up page `/auth`, password reset `/reset-password`
- [x] Test validation rules (vitest — 16 passing)
- [x] Verify in browser: browse, search, filter, sort, clear, book page, back
- [x] Save the project to the user's desktop (downloadable copy in Files)
- [ ] Verify add / edit / remove a book while signed in (needs a signed-in session)
- [ ] Verify the password-reset email round trip
