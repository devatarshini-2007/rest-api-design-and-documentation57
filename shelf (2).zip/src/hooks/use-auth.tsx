import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { useNavigate, useRouter } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import type { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { takeReturnTo } from "@/lib/auth-redirect";

type AuthValue = {
  session: Session | null;
  user: User | null;
  email: string | null;
  loading: boolean;
  isSignedIn: boolean;
  signOut: () => Promise<void>;
};

const AuthContext = createContext<AuthValue | null>(null);

/**
 * The app's single auth listener: keeps the header, the route loaders and the
 * query cache in step with the session.
 */
export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  useEffect(() => {
    let active = true;

    supabase.auth.getSession().then(({ data }) => {
      if (!active) return;
      setSession(data.session);
      setLoading(false);
    });

    const { data: subscription } = supabase.auth.onAuthStateChange((event, next) => {
      if (event !== "SIGNED_IN" && event !== "SIGNED_OUT" && event !== "USER_UPDATED") return;

      setSession(next);
      setLoading(false);
      router.invalidate();
      if (event !== "SIGNED_OUT") queryClient.invalidateQueries();

      if (event === "SIGNED_IN") {
        const target = takeReturnTo();
        if (target) navigate({ to: target as never, replace: true });
      }
    });

    return () => {
      active = false;
      subscription.subscription.unsubscribe();
    };
  }, [router, navigate, queryClient]);

  const value = useMemo<AuthValue>(
    () => ({
      session,
      user: session?.user ?? null,
      email: session?.user?.email ?? null,
      loading,
      isSignedIn: Boolean(session),
      signOut: async () => {
        await queryClient.cancelQueries();
        queryClient.clear();
        await supabase.auth.signOut();
        navigate({ to: "/auth", search: { redirect: "/", mode: "signin" }, replace: true });
      },
    }),
    [session, loading, queryClient, navigate],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthValue {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used inside <AuthProvider>");
  return context;
}
