import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Choose a new password — Shelf" },
      {
        name: "description",
        content: "Set a new password for your Shelf account.",
      },
      { property: "og:title", content: "Choose a new password — Shelf" },
      {
        property: "og:description",
        content: "Set a new password for your Shelf account.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ResetPasswordPage,
});

function ResetPasswordPage() {
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    // The recovery link arrives with the session in the URL hash; supabase-js
    // swaps it for a real session a beat after the page loads.
    let attempts = 0;
    const timer = window.setInterval(async () => {
      attempts += 1;
      const { data } = await supabase.auth.getSession();
      if (data.session || attempts > 15) {
        window.clearInterval(timer);
        setReady(Boolean(data.session));
      }
    }, 200);

    return () => window.clearInterval(timer);
  }, []);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (password.length < 6) {
      toast.error("Use at least 6 characters.");
      return;
    }

    setBusy(true);
    const { error } = await supabase.auth.updateUser({ password });
    if (error) {
      toast.error("Couldn't update your password", { description: error.message });
      setBusy(false);
      return;
    }

    await supabase.auth.signOut();
    toast.success("Password updated", { description: "Sign in with your new password." });
    navigate({ to: "/auth", search: { redirect: "/", mode: "signin" }, replace: true });
  }

  return (
    <div className="mx-auto w-full max-w-md px-5 py-20">
      <div className="rounded-2xl border border-border bg-card p-8">
        <h1 className="font-display text-xl font-semibold text-foreground">
          Choose a new password
        </h1>

        {!ready ? (
          <p className="mt-3 text-sm text-muted-foreground">
            Opening your reset link… If this page sits here too long, request a fresh link from the
            sign-in screen.
          </p>
        ) : (
          <form onSubmit={submit} className="mt-6 space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="new-password">New password</Label>
              <Input
                id="new-password"
                type="password"
                autoComplete="new-password"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                placeholder="At least 6 characters"
              />
            </div>
            <Button type="submit" className="w-full" disabled={busy}>
              {busy ? "Saving…" : "Save new password"}
            </Button>
          </form>
        )}
      </div>
    </div>
  );
}
