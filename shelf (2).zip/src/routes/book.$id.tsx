import { createFileRoute, notFound, useNavigate, Link } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { ArrowLeft, Pencil, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { StatusPill, Spine } from "@/components/book-card";
import { BookFormDialog } from "@/components/book-form-dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { supabase } from "@/integrations/supabase/client";
import { booksQueryOptions } from "@/lib/books-queries";
import { getBook } from "@/lib/books.functions";
import { rememberReturnTo } from "@/lib/auth-redirect";
import type { Book } from "@/lib/books";

const bookQueryOptions = (id: string) =>
  queryOptions({
    queryKey: ["book", id],
    queryFn: (): Promise<Book | null> => getBook({ data: { id } }),
  });

export const Route = createFileRoute("/book/$id")({
  loader: async ({ context, params }) => {
    const book = await context.queryClient.ensureQueryData(bookQueryOptions(params.id));
    if (!book) throw notFound();
    return book;
  },
  head: ({ loaderData }) => ({
    meta: [
      {
        title: loaderData
          ? `${loaderData.title} by ${loaderData.author} — Shelf`
          : "Book — Shelf",
      },
      {
        name: "description",
        content: loaderData
          ? `${loaderData.title} by ${loaderData.author}${loaderData.year ? `, ${loaderData.year}` : ""}. ${
              loaderData.status === "borrowed" ? "Currently on loan." : "Available now."
            }`
          : "A title on the Shelf community library catalogue.",
      },
      {
        property: "og:title",
        content: loaderData
          ? `${loaderData.title} by ${loaderData.author} — Shelf`
          : "Book — Shelf",
      },
      {
        property: "og:description",
        content: loaderData
          ? `${loaderData.title} by ${loaderData.author}. ${
              loaderData.status === "borrowed" ? "Currently on loan." : "Available now."
            }`
          : "A title on the Shelf community library catalogue.",
      },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: BookDetail,
  notFoundComponent: () => (
    <div className="mx-auto w-full max-w-3xl px-5 py-24 text-center">
      <h1 className="font-display text-2xl font-semibold text-foreground">
        That book isn't on the shelf
      </h1>
      <p className="mt-2 text-sm text-muted-foreground">
        It may have been removed, or the link is wrong.
      </p>
      <Button className="mt-6" asChild>
        <Link to="/">Back to the catalogue</Link>
      </Button>
    </div>
  ),
  errorComponent: ({ error }) => (
    <div className="mx-auto w-full max-w-3xl px-5 py-24 text-center" role="alert">
      <h1 className="font-display text-2xl font-semibold text-foreground">
        We couldn't load this book
      </h1>
      <p className="mt-2 text-sm text-muted-foreground">
        {error instanceof Error ? error.message : String(error)}
      </p>
    </div>
  ),
});

function BookDetail() {
  const { id } = Route.useParams();
  const { data } = useSuspenseQuery(bookQueryOptions(id));
  const book = data;

  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const { isSignedIn, email } = useAuth();

  const [formOpen, setFormOpen] = useState(false);

  if (!book) return null;

  async function requireSignIn() {
    rememberReturnTo(`/book/${book!.id}`);
    toast("Sign in to manage this book.");
    navigate({ to: "/auth", search: { redirect: `/book/${book!.id}`, mode: "signin" } });
  }

  async function toggleStatus() {
    if (!isSignedIn) return requireSignIn();
    const next = book!.status === "borrowed" ? "available" : "borrowed";
    const { error } = await supabase.from("books").update({ status: next }).eq("id", book!.id);
    if (error) {
      toast.error("Couldn't update availability", { description: error.message });
      return;
    }
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: booksQueryOptions.queryKey }),
      queryClient.invalidateQueries({ queryKey: ["book", book!.id] }),
    ]);
    toast.success(next === "borrowed" ? "Marked on loan" : "Marked available");
  }

  async function remove() {
    if (!isSignedIn) return requireSignIn();
    const { error } = await supabase.from("books").delete().eq("id", book!.id);
    if (error) {
      toast.error("Couldn't remove that book", { description: error.message });
      return;
    }
    await queryClient.invalidateQueries({ queryKey: booksQueryOptions.queryKey });
    toast.success("Removed from the shelf", { description: book!.title });
    navigate({ to: "/" });
  }

  const meta: Array<[string, string]> = [
    ["Category", book.category],
    ["Year", book.year ? String(book.year) : "—"],
    ["ISBN", book.isbn ?? "—"],
    ["Added by", book.added_by_email ?? "Original collection"],
  ];

  return (
    <>
      <div className="mx-auto w-full max-w-3xl px-5 py-8">
        <Link
          to="/"
          className="inline-flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to the catalogue
        </Link>

        <div className="mt-6 flex items-start gap-5">
          <Spine book={book} className="h-24 w-16 text-lg" />
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-3">
              <StatusPill status={book.status} />
              <span className="text-xs tracking-wide text-muted-foreground uppercase">
                {book.category}
              </span>
            </div>
            <h1 className="font-display mt-3 text-3xl leading-tight font-semibold text-foreground">
              {book.title}
            </h1>
            <p className="mt-2 text-lg text-muted-foreground">{book.author}</p>
          </div>
        </div>

        {book.notes && (
          <p className="mt-8 rounded-xl border border-border bg-card p-5 text-[15px] leading-relaxed text-foreground">
            {book.notes}
          </p>
        )}

        <dl className="mt-8 grid gap-px overflow-hidden rounded-xl border border-border bg-border sm:grid-cols-2">
          {meta.map(([label, value]) => (
            <div key={label} className="bg-card px-5 py-4">
              <dt className="text-xs tracking-wide text-muted-foreground uppercase">{label}</dt>
              <dd className="mt-1 truncate text-sm font-medium text-foreground">{value}</dd>
            </div>
          ))}
        </dl>

        <div className="mt-8 flex flex-wrap gap-2">
          <Button onClick={() => void toggleStatus()}>
            {book.status === "borrowed" ? "Mark available" : "Mark on loan"}
          </Button>
          <Button variant="outline" onClick={() => (isSignedIn ? setFormOpen(true) : requireSignIn())}>
            <Pencil className="h-4 w-4" />
            Edit details
          </Button>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="ghost" className="text-destructive hover:bg-destructive/10 hover:text-destructive">
                <Trash2 className="h-4 w-4" />
                Remove
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle className="font-display">
                  Remove “{book.title}”?
                </AlertDialogTitle>
                <AlertDialogDescription>
                  It will disappear from the catalogue for everyone. This can't be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Keep it</AlertDialogCancel>
                <AlertDialogAction onClick={() => void remove()}>Remove book</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>

        {!isSignedIn && (
          <p className="mt-6 text-sm text-muted-foreground">
            You're browsing as a guest.{" "}
            <button
              type="button"
              className="font-medium text-primary hover:underline"
              onClick={() =>
                navigate({
                  to: "/auth",
                  search: { redirect: `/book/${book.id}`, mode: "signin" },
                })
              }
            >
              Sign in
            </button>{" "}
            to lend, edit or remove titles.
            {email ? "" : ""}
          </p>
        )}
      </div>

      <BookFormDialog open={formOpen} onOpenChange={setFormOpen} book={book} />
    </>
  );
}
