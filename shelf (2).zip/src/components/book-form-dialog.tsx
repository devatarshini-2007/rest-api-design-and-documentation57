import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/hooks/use-auth";
import { booksQueryOptions } from "@/lib/books-queries";
import {
  DEFAULT_CATEGORIES,
  draftFromBook,
  emptyDraft,
  validateBook,
  type Book,
  type BookDraft,
  type BookFieldErrors,
} from "@/lib/books";

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  book: Book | null;
};

export function BookFormDialog({ open, onOpenChange, book }: Props) {
  const queryClient = useQueryClient();
  const { email } = useAuth();
  const [draft, setDraft] = useState<BookDraft>(emptyDraft);
  const [errors, setErrors] = useState<BookFieldErrors>({});
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (open) {
      setDraft(book ? draftFromBook(book) : emptyDraft());
      setErrors({});
    }
  }, [open, book]);

  const set = (patch: Partial<BookDraft>) => setDraft((prev) => ({ ...prev, ...patch }));

  async function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    const result = validateBook(draft);
    setErrors(result.errors);
    if (!result.ok) return;

    setSubmitting(true);
    try {
      if (book) {
        const { error } = await supabase.from("books").update(result.values).eq("id", book.id);
        if (error) throw error;
        toast.success("Saved", { description: result.values.title });
      } else {
        const { error } = await supabase
          .from("books")
          .insert({ ...result.values, added_by_email: email });
        if (error) throw error;
        toast.success("Added to the shelf", { description: result.values.title });
      }

      await queryClient.invalidateQueries({ queryKey: booksQueryOptions.queryKey });
      onOpenChange(false);
    } catch (error) {
      toast.error(book ? "Couldn't save that book" : "Couldn't add that book", {
        description: error instanceof Error ? error.message : String(error),
      });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display">
            {book ? "Edit this book" : "Add a book to the shelf"}
          </DialogTitle>
          <DialogDescription>
            Title and author are required. Everything else is optional.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="title">Title</Label>
            <Input
              id="title"
              value={draft.title}
              onChange={(e) => set({ title: e.target.value })}
              placeholder="The Left Hand of Darkness"
              aria-invalid={Boolean(errors.title)}
            />
            {errors.title && <p className="text-xs text-destructive">{errors.title}</p>}
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="author">Author</Label>
            <Input
              id="author"
              value={draft.author}
              onChange={(e) => set({ author: e.target.value })}
              placeholder="Ursula K. Le Guin"
              aria-invalid={Boolean(errors.author)}
            />
            {errors.author && <p className="text-xs text-destructive">{errors.author}</p>}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="year">Year</Label>
              <Input
                id="year"
                inputMode="numeric"
                value={draft.year}
                onChange={(e) => set({ year: e.target.value })}
                placeholder="1969"
                aria-invalid={Boolean(errors.year)}
              />
              {errors.year && <p className="text-xs text-destructive">{errors.year}</p>}
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="isbn">ISBN</Label>
              <Input
                id="isbn"
                value={draft.isbn}
                onChange={(e) => set({ isbn: e.target.value })}
                placeholder="978-0-441-47812-5"
                aria-invalid={Boolean(errors.isbn)}
              />
              {errors.isbn && <p className="text-xs text-destructive">{errors.isbn}</p>}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="category">Category</Label>
              <Input
                id="category"
                list="shelf-categories"
                value={draft.category}
                onChange={(e) => set({ category: e.target.value })}
                placeholder="Science Fiction"
              />
              <datalist id="shelf-categories">
                {DEFAULT_CATEGORIES.map((category) => (
                  <option key={category} value={category} />
                ))}
              </datalist>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="status">Status</Label>
              <Select
                value={draft.status}
                onValueChange={(value) => set({ status: value === "borrowed" ? "borrowed" : "available" })}
              >
                <SelectTrigger id="status">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="available">Available</SelectItem>
                  <SelectItem value="borrowed">On loan</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="notes">Note</Label>
            <Textarea
              id="notes"
              value={draft.notes}
              onChange={(e) => set({ notes: e.target.value })}
              placeholder="Why it's worth reading, or where it lives on the shelf."
              rows={3}
            />
          </div>

          <DialogFooter className="gap-2 pt-2">
            <Button
              type="button"
              variant="ghost"
              onClick={() => onOpenChange(false)}
              disabled={submitting}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={submitting}>
              {submitting ? "Saving…" : book ? "Save changes" : "Add book"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
