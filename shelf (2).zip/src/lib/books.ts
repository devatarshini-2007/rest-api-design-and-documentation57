/**
 * Catalogue rules shared by the forms, the list and the tests.
 *
 * Mirrors the validation the FastAPI capstone did on every incoming book:
 * trim the text, clean up the ISBN, and check the year.
 */

export type BookStatus = "available" | "borrowed";

export type Book = {
  id: string;
  title: string;
  author: string;
  isbn: string | null;
  year: number | null;
  category: string;
  status: BookStatus;
  notes: string | null;
  added_by: string | null;
  added_by_email: string | null;
  created_at: string;
  updated_at: string;
};

export const MIN_YEAR = 1000;
export const MAX_TITLE_LENGTH = 300;
export const MAX_AUTHOR_LENGTH = 200;
export const MAX_NOTES_LENGTH = 500;

export const DEFAULT_CATEGORIES = [
  "Fiction",
  "Non-fiction",
  "Science",
  "History",
  "Design",
  "Psychology",
  "Nature",
  "Memoir",
  "Science Fiction",
  "Poetry",
  "General",
];

export type BookDraft = {
  title: string;
  author: string;
  isbn: string;
  year: string;
  category: string;
  status: BookStatus;
  notes: string;
};

export type BookField = "title" | "author" | "isbn" | "year" | "category" | "notes";

export type BookFieldErrors = Partial<Record<BookField, string>>;

export type BookValues = {
  title: string;
  author: string;
  isbn: string | null;
  year: number | null;
  category: string;
  status: BookStatus;
  notes: string | null;
};

export type BookValidation = {
  ok: boolean;
  errors: BookFieldErrors;
  values: BookValues;
};

/** Collapse every run of whitespace to one space and trim both ends. */
export function cleanText(value: string): string {
  return value.replace(/\s+/g, " ").trim();
}

/**
 * Strip ISBN separators and keep only what is meaningful: digits, plus a
 * trailing X for an ISBN-10 check digit.
 */
export function normalizeIsbn(value: string): string {
  return value.toUpperCase().replace(/[^0-9X]/g, "").replace(/X(?!$)/g, "");
}

export function isValidIsbn(value: string): boolean {
  const n = normalizeIsbn(value);
  return /^\d{13}$/.test(n) || /^\d{9}[0-9X]$/.test(n);
}

export function currentYear(): number {
  return new Date().getFullYear();
}

export function emptyDraft(): BookDraft {
  return {
    title: "",
    author: "",
    isbn: "",
    year: "",
    category: "",
    status: "available",
    notes: "",
  };
}

export function draftFromBook(book: Book): BookDraft {
  return {
    title: book.title,
    author: book.author,
    isbn: book.isbn ?? "",
    year: book.year === null ? "" : String(book.year),
    category: book.category,
    status: book.status,
    notes: book.notes ?? "",
  };
}

/** Trim text, clean the ISBN and check the year — the same three gates as the API. */
export function validateBook(draft: BookDraft, maxYear: number = currentYear()): BookValidation {
  const errors: BookFieldErrors = {};

  const title = cleanText(draft.title);
  if (!title) errors.title = "A title is required.";
  else if (title.length > MAX_TITLE_LENGTH)
    errors.title = `Keep the title under ${MAX_TITLE_LENGTH} characters.`;

  const author = cleanText(draft.author);
  if (!author) errors.author = "An author is required.";
  else if (author.length > MAX_AUTHOR_LENGTH)
    errors.author = `Keep the author under ${MAX_AUTHOR_LENGTH} characters.`;

  const isbnRaw = cleanText(draft.isbn);
  const isbn = normalizeIsbn(isbnRaw);
  if (isbnRaw && !isValidIsbn(isbnRaw))
    errors.isbn = "An ISBN must be 10 or 13 digits (an ISBN-10 may end in X).";

  const yearRaw = cleanText(draft.year);
  let year: number | null = null;
  if (yearRaw) {
    const parsed = Number(yearRaw);
    if (!Number.isInteger(parsed)) errors.year = "The year must be a whole number.";
    else if (parsed < MIN_YEAR) errors.year = `The year must be ${MIN_YEAR} or later.`;
    else if (parsed > maxYear) errors.year = `The year cannot be later than ${maxYear}.`;
    else year = parsed;
  }

  const category = cleanText(draft.category) || "General";
  if (cleanText(draft.category) && cleanText(draft.category).length > 60)
    errors.category = "Keep the category under 60 characters.";

  const notes = cleanText(draft.notes);
  if (notes.length > MAX_NOTES_LENGTH)
    errors.notes = `Keep the note under ${MAX_NOTES_LENGTH} characters.`;

  return {
    ok: Object.keys(errors).length === 0,
    errors,
    values: {
      title,
      author,
      isbn: isbn || null,
      year,
      category,
      status: draft.status === "borrowed" ? "borrowed" : "available",
      notes: notes || null,
    },
  };
}

export type CatalogueFilters = {
  q: string;
  category: string;
  status: string;
  sort: string;
};

/** Search across title, author, ISBN and category, then filter and sort. */
export function selectBooks(books: Book[], filters: CatalogueFilters): Book[] {
  const q = cleanText(filters.q).toLowerCase();

  let rows = books.filter((book) => {
    if (filters.category !== "all" && book.category !== filters.category) return false;
    if (filters.status !== "all" && book.status !== filters.status) return false;
    if (!q) return true;
    const haystack = [
      book.title,
      book.author,
      book.category,
      book.isbn ?? "",
      book.year === null ? "" : String(book.year),
    ]
      .join(" ")
      .toLowerCase();
    return haystack.includes(q);
  });

  rows = [...rows];

  switch (filters.sort) {
    case "title":
      rows.sort((a, b) => a.title.localeCompare(b.title));
      break;
    case "author":
      rows.sort((a, b) => a.author.localeCompare(b.author));
      break;
    case "year":
      rows.sort((a, b) => (b.year ?? 0) - (a.year ?? 0));
      break;
    default:
      rows.sort((a, b) => b.created_at.localeCompare(a.created_at));
  }

  return rows;
}

const SPINES = ["bg-spine-1", "bg-spine-2", "bg-spine-3", "bg-spine-4", "bg-spine-5"];

/** Deterministic spine colour so a book always looks the same. */
export function spineClass(seed: string): string {
  let hash = 0;
  for (let i = 0; i < seed.length; i += 1) {
    hash = (hash * 31 + seed.charCodeAt(i)) >>> 0;
  }
  return SPINES[hash % SPINES.length] ?? "bg-spine-1";
}

export function initials(title: string): string {
  const words = cleanText(title)
    .split(" ")
    .filter((word) => !["a", "an", "the", "of", "and", "in", "on"].includes(word.toLowerCase()));
  const letters = (words.length ? words : cleanText(title).split(" "))
    .slice(0, 2)
    .map((word) => word[0]?.toUpperCase() ?? "")
    .join("");
  return letters || "?";
}
