import { describe, expect, it } from "vitest";
import {
  cleanText,
  currentYear,
  initials,
  isValidIsbn,
  normalizeIsbn,
  selectBooks,
  validateBook,
  type Book,
} from "./books";

const book = (over: Partial<Book> = {}): Book => ({
  id: "11111111-1111-4111-8111-111111111111",
  title: "Piranesi",
  author: "Susanna Clarke",
  isbn: "9781635575637",
  year: 2020,
  category: "Fiction",
  status: "available",
  notes: null,
  added_by: null,
  added_by_email: null,
  created_at: "2026-01-02T00:00:00.000Z",
  updated_at: "2026-01-02T00:00:00.000Z",
  ...over,
});

describe("cleanText", () => {
  it("trims the ends and collapses the middle", () => {
    expect(cleanText("  The   Overstory \n ")).toBe("The Overstory");
  });
});

describe("normalizeIsbn", () => {
  it("strips separators and keeps a trailing X", () => {
    expect(normalizeIsbn("978-0-441-47812-5")).toBe("9780441478125");
    expect(normalizeIsbn(" 0-8044-2957-X ")).toBe("080442957X");
  });

  it("drops an X that is not the final check digit", () => {
    expect(normalizeIsbn("9780X441478125")).toBe("9780441478125");
  });
});

describe("isValidIsbn", () => {
  it("accepts cleaned 13-digit, 10-digit and X-ended ISBNs", () => {
    expect(isValidIsbn("978-0-062-31609-7")).toBe(true);
    expect(isValidIsbn("080442957X")).toBe(true);
  });

  it("rejects the wrong length and stray letters", () => {
    expect(isValidIsbn("978006231609")).toBe(false);
    expect(isValidIsbn("not-an-isbn")).toBe(false);
    expect(isValidIsbn("")).toBe(false);
  });
});

describe("validateBook", () => {
  const draft = {
    title: "  Sapiens  ",
    author: " Yuval   Noah Harari ",
    isbn: "978-0-062-31609-7",
    year: "2011",
    category: " History ",
    status: "available" as const,
    notes: "",
  };

  it("trims text and stores a normalised ISBN", () => {
    const result = validateBook(draft);
    expect(result.ok).toBe(true);
    expect(result.values.title).toBe("Sapiens");
    expect(result.values.author).toBe("Yuval Noah Harari");
    expect(result.values.isbn).toBe("9780062316097");
    expect(result.values.year).toBe(2011);
    expect(result.values.category).toBe("History");
    expect(result.values.notes).toBeNull();
  });

  it("requires a title and an author", () => {
    const result = validateBook({ ...draft, title: "   ", author: "" });
    expect(result.ok).toBe(false);
    expect(result.errors.title).toBe("A title is required.");
    expect(result.errors.author).toBe("An author is required.");
  });

  it("rejects a year in the future", () => {
    const result = validateBook({ ...draft, year: String(currentYear() + 1) });
    expect(result.ok).toBe(false);
    expect(result.errors.year).toContain(`later than ${currentYear()}`);
  });

  it("rejects a year before 1000 and a non-number", () => {
    expect(validateBook({ ...draft, year: "0812" }).errors.year).toBe(
      "The year must be 1000 or later.",
    );
    expect(validateBook({ ...draft, year: "19th" }).errors.year).toBe(
      "The year must be a whole number.",
    );
  });

  it("rejects a malformed ISBN but lets an empty one through", () => {
    expect(validateBook({ ...draft, isbn: "12345" }).errors.isbn).toBeDefined();
    expect(validateBook({ ...draft, isbn: "  " }).ok).toBe(true);
    expect(validateBook({ ...draft, isbn: "  " }).values.isbn).toBeNull();
  });

  it("defaults a blank category to General", () => {
    expect(validateBook({ ...draft, category: "  " }).values.category).toBe("General");
  });
});

describe("selectBooks", () => {
  const rows = [
    book({ id: "a", title: "Piranesi", author: "Susanna Clarke", year: 2020, category: "Fiction" }),
    book({
      id: "b",
      title: "Sapiens",
      author: "Yuval Noah Harari",
      isbn: "9780062316097",
      year: 2011,
      category: "History",
      status: "borrowed",
    }),
    book({
      id: "c",
      title: "Braiding Sweetgrass",
      author: "Robin Wall Kimmerer",
      year: 2013,
      category: "Nature",
    }),
  ];

  const all = { q: "", category: "all", status: "all", sort: "recent" };

  it("matches on author and ISBN, not just title", () => {
    expect(selectBooks(rows, { ...all, q: "kimmerer" }).map((row) => row.id)).toEqual(["c"]);
    expect(selectBooks(rows, { ...all, q: "9780062316097" }).map((row) => row.id)).toEqual(["b"]);
  });

  it("filters by category and availability together", () => {
    expect(selectBooks(rows, { ...all, category: "Fiction", status: "available" })).toHaveLength(1);
    expect(selectBooks(rows, { ...all, status: "borrowed" }).map((row) => row.id)).toEqual(["b"]);
  });

  it("sorts by title, and by newest published first", () => {
    expect(selectBooks(rows, { ...all, sort: "title" }).map((row) => row.title)).toEqual([
      "Braiding Sweetgrass",
      "Piranesi",
      "Sapiens",
    ]);
    expect(selectBooks(rows, { ...all, sort: "year" }).map((row) => row.id)).toEqual(["a", "c", "b"]);
  });
});

describe("initials", () => {
  it("skips leading articles", () => {
    expect(initials("The Left Hand of Darkness")).toBe("LH");
  });
});
