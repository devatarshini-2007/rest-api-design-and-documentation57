UPDATE public.books
SET notes = 'An envoy on an ice-bound world where gender is fluid.'
WHERE title = 'The Left Hand of Darkness';