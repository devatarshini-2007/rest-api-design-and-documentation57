# Shelf — Community Library Catalogue

A web app for a small library: browse and search the catalogue, see which titles are out on loan,
and add books of your own.

Built on TanStack Start (React 19), Tailwind CSS v4, shadcn/ui, with a hosted database and
sign-in underneath.

## Running it

```bash
bun install
bun run dev        # http://localhost:8080
```

```bash
bun run test       # the catalogue rules
bun run lint       # eslint
bun run format     # prettier
```

## What's inside

| Path | What it does |
| --- | --- |
| `src/routes/index.tsx` | The catalogue: search, category and availability filters, sort, add a book |
| `src/routes/book.$id.tsx` | One book: mark on loan, edit details, remove |
| `src/routes/auth.tsx` | Sign in / create account — email and password, Google, or Lovable |
| `src/routes/reset-password.tsx` | Choose a new password from a reset link |
| `src/lib/books.ts` | The catalogue rules: trim text, clean up the ISBN, check the year, filter, sort |
| `src/lib/books.test.ts` | Tests for those rules (`bun run test`) |
| `src/lib/books.functions.ts` | Server-side reads of the catalogue |
| `src/hooks/use-auth.tsx` | The app's one session listener, and sign-out |
| `public/catalogue.html` | A standalone HTML page showing the live catalogue — open it in any browser or host it on GitHub Pages |
| `drizzle/migrations/` | The `books` table, its access rules, and the sample shelf |

## Notes

- Anyone can browse the shelf. Signing in is needed to add, edit or remove a title.
- Book records are checked on the way in: text is trimmed, the ISBN is stripped down to 10 or 13
  digits, and the year must be a whole number between 1000 and this year.
- `.env` points the app at its hosted database and sign-in. Without it the pages still render,
  but the catalogue comes back empty.
